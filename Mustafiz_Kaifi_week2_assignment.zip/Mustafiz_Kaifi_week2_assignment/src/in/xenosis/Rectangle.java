package in.xenosis;


//Write a program that uses constructors to
//        initialize objects and demonstrates method
//        overloading.

public class Rectangle {
    double length;
    double width;
    public Rectangle() {
        this.length = 4.0;
        this.width = 5.0;
    }

    public Rectangle(double side) {
        this.length = side;
        this.width = side;
    }

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    public double calculateArea() {
        return length * width;
    }
    public double calculatePerimeter() {
        return 2 * (length + width);
    }
    public void display() {
        System.out.println("Length: " + length);
        System.out.println("Width: " + width);
        System.out.println("Area: " + calculateArea());
        System.out.println("Perimeter: " + calculatePerimeter());
    }
    public void display(String message) {
        System.out.println(message);
        display();
    }

    public static void main(String[] args) {

        Rectangle rect1 = new Rectangle();
        rect1.display("Rectangle 1:");

        Rectangle rect2 = new Rectangle(5.0);
        rect2.display("Rectangle 2 (Square):");

        Rectangle rect3 = new Rectangle(4.0, 6.0);
        rect3.display("Rectangle 3:");

        rect3.display("Rectangle 3 again with overloaded method:");
    }
}
