package in.xenosis;


//Create a class Person with attributes like name,
//        age, and methods to display these attributes.

public class Person {
    String name;
    int age;


    //By using Method
    void display(){
        this.name=name;
        this.age=age;
        System.out.println(name);
        System.out.println(age);

    }

    public static void main(String[] args) {
        Person p=new Person();
        p.age=23;
        p.name="Mustafiz Kaifi";
        p.display();
    }
}



