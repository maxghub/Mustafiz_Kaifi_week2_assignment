package in.xenosis;


//Implement a BankAccount class with methods
//for deposit, withdrawal, and displaying the
//        account balance

import java.util.Scanner;

public class Bankapplication {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("You want to start account from how much money: ");
        double balance=sc.nextDouble();
        double deposit,withdraw;
        while (true){
            System.out.println("click 1 for withraw the money from your account :");
            System.out.println("click 2 for deposit the money in your account :");
            System.out.println("click 3 for display the balance :");
            System.out.println("click 4 for exit :");
            System.out.println();
            System.out.println("Please enter your choice : ");

            int choice=sc.nextInt();
            switch (choice){
                case 1:
                    System.out.println("Enter the money for withdrawal : ");
                    withdraw=sc.nextDouble();
                    balance=balance-withdraw;
                    System.out.println("Now your balance is in your account: "+balance);
                    break;

                case 2:
                    System.out.println("ENter the money to deposit : ");
                    deposit=sc.nextDouble();
                    balance=balance+deposit;
                    System.out.println("you total balance is : "+balance);
                    break;

                case 3:
                    System.out.println("Your balance in your account : "+balance);
                    break;

                default:
                    System.exit(0);

            }

        }
    }
}
